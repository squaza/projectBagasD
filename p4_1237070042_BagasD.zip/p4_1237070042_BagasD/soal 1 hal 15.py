import cv2
import matplotlib.pyplot as plt

img = cv2.imread('cat.jpg', cv2.IMREAD_GRAYSCALE)

# Proses transformasi negatif (s = 255 - r)
img_negatif = 255 - img

plt.figure(figsize=(10, 5))
plt.subplot(121), plt.imshow(img, cmap='gray'), plt.title('Citra Asli')
plt.subplot(122), plt.imshow(img_negatif, cmap='gray'), plt.title('Hasil Negatif')
plt.show()
