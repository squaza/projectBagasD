import cv2
import numpy as np
import matplotlib.pyplot as plt


# Membaca gambar 'cat.jpg' dalam format grayscale
img_asli = cv2.imread('cat.jpg', cv2.IMREAD_GRAYSCALE)
img_low = cv2.normalize(img_asli, None, 100, 160, cv2.NORM_MINMAX)
img_high = cv2.equalizeHist(img_asli)
img_dark = np.clip(img_asli.astype(np.int16) - 100, 0, 255).astype(np.uint8)
img_bright = np.clip(img_asli.astype(np.int16) + 100, 0, 255).astype(np.uint8)

# Menyimpan citra dan judul ke dalam list untuk keperluan looping
images = [img_low, img_high, img_dark, img_bright]
titles = ['Low Contrast', 'High Contrast', 'Under Exposed (Gelap)', 'Over Exposed (Terang)']

def calculate_normalized_histogram(image):
    # np.histogram mengembalikan array jumlah piksel per bin
    histogram, _ = np.histogram(image, bins=256, range=(0, 256))
    total_pixels = image.size 
    normalized_histogram = histogram / total_pixels
    return normalized_histogram

plt.figure(figsize=(15, 10))

for i in range(4):
    # Hitung normalisasi histogram untuk masing-masing variasi citra kucing
    norm_hist = calculate_normalized_histogram(images[i])
    
    # Membuat subplot 2x2
    plt.subplot(2, 2, i + 1)
    
    # Menampilkan grafik menggunakan plt.bar sesuai standard visualisasi distribusi
    plt.bar(range(256), norm_hist, color='black', width=1.0)
    
    # Memberikan keterangan teks pada grafik
    plt.title(f"Normalisasi Histogram - Kucing {titles[i]}")
    plt.xlabel("Intensitas Piksel (r)")
    plt.ylabel("Distribusi Probabilitas P(r)")
    plt.xlim([0, 256]) # Membatasi sumbu X dari skala 0-255

plt.tight_layout()
plt.show()
