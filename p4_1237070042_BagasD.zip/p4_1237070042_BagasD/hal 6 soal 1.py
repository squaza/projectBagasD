import cv2
import numpy as np
import matplotlib.pyplot as plt

# Membaca gambar asli dalam format grayscale
img_asli = cv2.imread('cat.jpg', cv2.IMREAD_GRAYSCALE)

# Pembuatan 4 variasi citra secara manual
img_low = cv2.normalize(img_asli, None, 100, 160, cv2.NORM_MINMAX)
img_high = np.clip(1.5 * img_asli.astype(np.float32) - 50, 0, 255).astype(np.uint8)
img_dark = np.clip(img_asli.astype(np.int16) - 100, 0, 255).astype(np.uint8)
img_bright = np.clip(img_asli.astype(np.int16) + 100, 0, 255).astype(np.uint8)

images = [img_low, img_high, img_dark, img_bright]
titles = ['Low Contrast', 'High Contrast', 'Under Exposed', 'Over Exposed']

# Menampilkan grafik citra dan histogram biasa
plt.figure(figsize=(14, 12))
for i in range(4):
    plt.subplot(4, 2, 2*i + 1)
    plt.imshow(images[i], cmap='gray', vmin=0, vmax=255)
    plt.title(titles[i])
    plt.axis('off')
    
    plt.subplot(4, 2, 2*i + 2)
    plt.hist(images[i].ravel(), bins=256, range=(0, 256), color='gray')
    plt.title(f"Histogram {titles[i]}")
    plt.xlabel('Pixel Intensity')
    plt.ylabel('Number of Pixels')
    plt.xlim([0, 256])

plt.tight_layout()
plt.show()
