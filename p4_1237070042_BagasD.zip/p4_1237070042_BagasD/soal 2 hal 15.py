import cv2
import numpy as np
import matplotlib.pyplot as plt

# Fungsi hitung nilai kualitas citra (MSE dan PSNR) secara manual
def hitung_metrik_manual(citra_asli, citra_hasil):
    mse = np.mean((citra_asli.astype(np.float64) - citra_hasil.astype(np.float64)) ** 2)
    psnr = float('inf') if mse == 0 else 10 * np.log10((255 ** 2) / mse)
    return mse, psnr

img = cv2.imread('cat.jpg', cv2.IMREAD_GRAYSCALE)

# Penerapan rumus log dengan konstanta standar modul
c_standar = 255 / np.log(1 + np.max(img))
log_img1 = np.array(c_standar * (np.log(img + 1)), dtype=np.uint8)

# Penerapan rumus log dengan konstanta kustom
c_custom = 150 / np.log(1 + np.max(img))
log_img2 = np.array(c_custom * (np.log(img + 1)), dtype=np.uint8)

# Perhitungan metrik evaluasi
mse, psnr = hitung_metrik_manual(img, log_img1)
print(f"Metrik Log Standar -> MSE: {mse:.2f}, PSNR: {psnr:.2f} dB")

# Menampilkan perbandingan citra
plt.figure(figsize=(12, 4))
plt.subplot(131), plt.imshow(img, cmap='gray'), plt.title('Citra Asli')
plt.subplot(132), plt.imshow(log_img1, cmap='gray'), plt.title('Log c Standar')
plt.subplot(133), plt.imshow(log_img2, cmap='gray'), plt.title('Log c Kustom')
plt.show()
