import cv2
import numpy as np

# Fungsi hitung nilai kualitas citra (MSE dan PSNR) secara manual
def hitung_metrik_manual(citra_asli, citra_hasil):
    mse = np.mean((citra_asli.astype(np.float64) - citra_hasil.astype(np.float64)) ** 2)
    psnr = float('inf') if mse == 0 else 10 * np.log10((255 ** 2) / mse)
    return mse, psnr

img = cv2.imread('cat.jpg', cv2.IMREAD_GRAYSCALE)
gammas = [0.1, 0.5, 1.2, 2.2]

print(f"{'Gamma':<8}{'MSE':<12}{'PSNR (dB)':<12}")
# Perulangan penerapan tiap nilai gamma sesuai soal tugas
for g in gammas:
    gamma_corrected = np.array(255 * (img / 255) ** g, dtype='uint8')
    mse_g, psnr_g = hitung_metrik_manual(img, gamma_corrected)
    print(f"{g:<8}{mse_g:<12.2f}{psnr_g:<12.2f}")
