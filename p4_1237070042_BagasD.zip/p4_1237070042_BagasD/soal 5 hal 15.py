import cv2
import numpy as np
import matplotlib.pyplot as plt

# Fungsi hitung nilai kualitas citra (MSE dan PSNR) secara manual
def hitung_metrik_manual(citra_asli, citra_hasil):
    mse = np.mean((citra_asli.astype(np.float64) - citra_hasil.astype(np.float64)) ** 2)
    psnr = float('inf') if mse == 0 else 10 * np.log10((255 ** 2) / mse)
    return mse, psnr

img = cv2.imread('cat.jpg', cv2.IMREAD_GRAYSCALE)

# Penerapan perataan histogram global
img_he = cv2.equalizeHist(img)

# Perhitungan metrik evaluasi
mse_he, psnr_he = hitung_metrik_manual(img, img_he)
print(f"Metrik HE -> MSE: {mse_he:.2f}, PSNR: {psnr_he:.2f} dB")

# Menampilkan perbandingan gambar dan histogram dengan perbaikan sintaks range
plt.figure(figsize=(12, 6))
plt.subplot(221), plt.imshow(img, cmap='gray'), plt.title('Citra Asli')

# PERBAIKAN: Mengubah [0, 256] posisional menjadi keyword argument range=(0, 256)
plt.subplot(222), plt.hist(img.ravel(), 256, range=(0, 256)), plt.title('Hist Asli')

plt.subplot(223), plt.imshow(img_he, cmap='gray'), plt.title('Hasil HE')

# PERBAIKAN: Mengubah [0, 256] posisional menjadi keyword argument range=(0, 256)
plt.subplot(224), plt.hist(img_he.ravel(), 256, range=(0, 256)), plt.title('Hist HE')

plt.tight_layout()
plt.show()
