import cv2
import numpy as np
import matplotlib.pyplot as plt

img = cv2.imread('cat.jpg', cv2.IMREAD_GRAYSCALE)
img_low = cv2.normalize(img, None, 100, 160, cv2.NORM_MINMAX)

# Peregangan kontras: o(i,j) = [(u(i,j) - c) / (d - c)] * 255
c, d = np.min(img_low), np.max(img_low)
out = ((img_low - c) / (d - c) * 255).astype(np.uint8)

# Menampilkan citra dan perubahan bentuk grafik histogram
plt.figure(figsize=(12, 5))
plt.subplot(221), plt.imshow(img_low, cmap='gray'), plt.title('Sebelum')
plt.subplot(222), plt.hist(img_low.ravel(), bins=256, range=(0,256)), plt.title('Hist Sebelum')
plt.subplot(223), plt.imshow(out, cmap='gray'), plt.title('Sesudah')
plt.subplot(224), plt.hist(out.ravel(), bins=256, range=(0,256)), plt.title('Hist Sesudah')
plt.tight_layout()
plt.show()
