import cv2
import numpy as np

# Fungsi hitung nilai kualitas citra (MSE dan PSNR) secara manual
def hitung_metrik_manual(citra_asli, citra_hasil):
    mse = np.mean((citra_asli.astype(np.float64) - citra_hasil.astype(np.float64)) ** 2)
    psnr = float('inf') if mse == 0 else 10 * np.log10((255 ** 2) / mse)
    return mse, psnr

img = cv2.imread('cat.jpg', cv2.IMREAD_GRAYSCALE)

# Perbandingan metode HE Global dan CLAHE Lokal Adaptif
img_he = cv2.equalizeHist(img)
clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8,8))
img_clahe = clahe.apply(img)

# Perhitungan metrik perbandingan nilai kualitas
mse_he, psnr_he = hitung_metrik_manual(img, img_he)
mse_cl, psnr_cl = hitung_metrik_manual(img, img_clahe)

print(f"Metrik HE    -> MSE: {mse_he:.2f}, PSNR: {psnr_he:.2f} dB")
print(f"Metrik CLAHE -> MSE: {mse_cl:.2f}, PSNR: {psnr_cl:.2f} dB")
